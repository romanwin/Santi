export var data = {
	facebook: 'https://www.facebook.com/ionicframework',
	phoneNumber: '+306973216110',
	email: {
		to: 'skounis@gmail.com',
		subject: 'Cordova Icons',
		body: 'How are you? Nice greetings from Leipzig'
	},
	officeLocation: '37.7736854,-122.421034'
};