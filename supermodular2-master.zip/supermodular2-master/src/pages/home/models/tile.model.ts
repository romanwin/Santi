export class Tile {
	public title: string;
	public path: string;
	public icon: string;
	public component: any;
}