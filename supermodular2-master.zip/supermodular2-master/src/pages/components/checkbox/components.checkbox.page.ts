import { Component } from '@angular/core';

@Component({
	templateUrl: 'components.checkbox.html'
})

export class ComponentsCheckboxPage {

}
