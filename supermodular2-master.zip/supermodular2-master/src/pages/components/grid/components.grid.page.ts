import { Component } from '@angular/core';


@Component({
	templateUrl: 'components.grid.html'
})
export class ComponentsGridPage {
}
