import { Component } from '@angular/core';


@Component({
	templateUrl: 'components.inputs.inline-labels.html'
})
export class ComponentsInputsInlineLabelsPage {

}
