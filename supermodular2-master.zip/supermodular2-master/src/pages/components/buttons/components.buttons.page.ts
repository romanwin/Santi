import { Component } from '@angular/core';

@Component({
	templateUrl: 'components.buttons.html'
})

export class ComponentsButtonsPage {

}
